import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { HomeComponent } from './core/home/home.component';
import { CategoriesComponent } from './categories/categories.component';
import { SubcategoriesComponent } from './subcategories/subcategories.component';

const appRoute: Routes=[
    {path:'',component:HomeComponent},
    {path:'categories',component:CategoriesComponent},
    {path:'subcategories',component:SubcategoriesComponent}
    
    
    
]
@NgModule({
    imports:[RouterModule.forRoot(appRoute)],
    exports:[RouterModule]
})
export class AppRoutingModule{

}