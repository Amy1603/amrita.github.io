import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from 'src/app/shared/data.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit,OnDestroy {
  open;
  locations;
  branches;
  show=false;
  locationId:number;
  arrData: string[];
  subscription: Subscription;

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.open=false;
    if(this.open=true){
      this.subscription=this.dataService.getData().subscribe(
        data=>{
            this.arrData = data as string[]
            this.locations = this.arrData['data'].locations;
          }
    );
      
  }
}

  toggle(){
    this.open=!this.open;
    
  }

  onShow(index:number){
    
    this.locationId = index;
    this.open=true;
    this.show=true;
    
    this.branches=this.locations[index].branches;
     
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
  
}
