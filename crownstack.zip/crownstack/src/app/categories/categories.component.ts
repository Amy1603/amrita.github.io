import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { DataService } from '../shared/data.service';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit,OnDestroy {
  locationId:number;
  branchId:number;
  arrData: string[];
  category:[];
  subscription:Subscription;

  constructor(private dataService: DataService,
              private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.queryParams.subscribe((queryParams:Params)=>{
      this.locationId=+queryParams['locationIndex'];
      this.branchId=+queryParams['branchIndex'];
    });
    this.subscription=this.dataService.getData().subscribe(
        data=>{
          this.arrData = data as string[]
          this.category=this.arrData['data'].locations[this.locationId].branches[this.branchId].categories;
          console.log(this.category);
        }
      );
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}
