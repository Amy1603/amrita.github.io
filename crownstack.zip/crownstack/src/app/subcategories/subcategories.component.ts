import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from '../shared/data.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-subcategories',
  templateUrl: './subcategories.component.html',
  styleUrls: ['./subcategories.component.css']
})
export class SubcategoriesComponent implements OnInit,OnDestroy {
  arrData: string[];
  subcategory:[];
  subscription:Subscription;
  categoryId:number;
  locationId:number;
  branchId:number;
  categoryName;

  constructor(private dataService: DataService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit() {
    this.route.queryParams.subscribe((queryParams:Params)=>{
      this.categoryId=+queryParams['categoryIndex'];
      this.locationId=+queryParams['locationIndex'];
      this.branchId=+queryParams['branchIndex'];
      
    });
    this.subscription=this.dataService.getData().subscribe(
        data=>{
          this.arrData = data as string[];
          this.subcategory=this.arrData['data'].locations[this.locationId].branches[this.branchId].categories[this.categoryId].subcategories;
          this.categoryName=this.arrData['data'].locations[this.locationId].branches[this.branchId].categories[this.categoryId].name;
          console.log(this.subcategory);
        }
      );
  }

  navigate(){
    this.router.navigate(['/categories'],{queryParams: this.route.snapshot.queryParams });
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}
